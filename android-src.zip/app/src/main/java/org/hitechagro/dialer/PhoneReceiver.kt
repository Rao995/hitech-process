package org.hitechagro.dialer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/** Call started → "on call" in Team live; call ended → sync the call + recording. */
class PhoneReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) { SyncWorker.schedule(c); return }
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val pending = goAsync()
        Thread {
            try {
                when (state) {
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> { Prefs.set(c, "in_call", "1"); CallSync.heartbeat(c, true) }
                    TelephonyManager.EXTRA_STATE_IDLE -> { Prefs.set(c, "in_call", "0"); CallSync.heartbeat(c, false); SyncWorker.soon(c) }
                }
            } finally { pending.finish() }
        }.start()
    }
}
