package org.hitechagro.dialer

import android.app.Notification
import android.content.Context
import android.provider.ContactsContract
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

/** Logs WhatsApp calls (who / when / how long) from WhatsApp's own call notifications.
 *  WhatsApp does not allow any app to record its calls — only the log is possible. */
class WaListener : NotificationListenerService() {
    private data class Live(val name: String, var dir: String, val start: Long, var connected: Long)
    private val live = HashMap<String, Live>()
    private val pkgs = setOf("com.whatsapp", "com.whatsapp.w4b")

    private fun isCall(n: Notification, text: String) = n.category == Notification.CATEGORY_CALL || Regex("(voice|video) call|calling|ringing", RegexOption.IGNORE_CASE).containsMatchIn(text)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in pkgs || Prefs.get(this, "wa_on") == "0") return
        val n = sbn.notification ?: return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (!isCall(n, text)) return
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
        if (!ongoing) {
            if (text.contains("missed", true)) log(this, title, "missed", System.currentTimeMillis(), 0)
            return
        }
        val l = live.getOrPut(sbn.key) { Live(title, if (text.contains("incoming", true)) "in" else "out", System.currentTimeMillis(), 0L) }
        if (l.connected == 0L && Regex("ongoing|\\d+:\\d\\d", RegexOption.IGNORE_CASE).containsMatchIn(text)) l.connected = System.currentTimeMillis()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val l = live.remove(sbn.key) ?: return
        val now = System.currentTimeMillis()
        val dur = if (l.connected > 0) ((now - l.connected) / 1000).toInt() else 0
        log(this, l.name, if (dur == 0 && l.dir == "in") "missed" else l.dir, l.start, dur)
    }

    companion object {
        fun numberFor(c: Context, name: String): String? = runCatching {
            c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} = ?", arrayOf(name), null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull()

        fun log(c: Context, name: String, dir: String, start: Long, dur: Int) {
            Thread {
                runCatching {
                    val phone = numberFor(c, name) ?: name
                    val id = Api(c).rpc("ht_crm_log_call", JSONObject().put("p", JSONObject().put("phone", phone).put("contact_name", name)
                        .put("direction", dir).put("channel", "whatsapp").put("started_at", CallSync.isoOf(start)).put("duration_sec", dur)
                        .put("device_key", CallSync.deviceId(c) + "-wa-" + start))).trim().trim('"')
                    if (dur > 0) CallSync.notifyStatus(c, id, "$name (WhatsApp)", dir, dur)
                }
            }.start()
        }
    }
}
