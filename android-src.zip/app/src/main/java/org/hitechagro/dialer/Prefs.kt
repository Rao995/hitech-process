package org.hitechagro.dialer

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("hitech", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): String? = sp(c).getString(k, null)
    fun set(c: Context, k: String, v: String?) { sp(c).edit().putString(k, v).apply() }
    fun long(c: Context, k: String): Long = sp(c).getLong(k, 0L)
    fun setLong(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
    fun clearLogin(c: Context) { sp(c).edit().remove("access").remove("refresh").remove("email").remove("expires").apply() }

    const val APP_URL = "https://rao995.github.io/hitech-process/"
}
