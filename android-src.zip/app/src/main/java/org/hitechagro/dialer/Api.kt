package org.hitechagro.dialer

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Talks to the Hi-Tech Process Supabase (same login as the web app). */
class Api(private val c: Context) {
    class ApiError(msg: String) : Exception(msg)

    private fun http(method: String, url: String, body: ByteArray?, headers: Map<String, String>): Pair<Int, String> {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method; con.connectTimeout = 20000; con.readTimeout = 60000
        headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
        if (body != null) { con.doOutput = true; con.outputStream.use { it.write(body) } }
        val code = con.responseCode
        val text = (if (code < 400) con.inputStream else con.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        con.disconnect()
        return code to text
    }

    /** Reads url + anon key from the published web app's config.js */
    fun config(): Pair<String, String> {
        val u = Prefs.get(c, "sb_url"); val k = Prefs.get(c, "sb_key")
        if (u != null && k != null) return u to k
        val (code, js) = http("GET", Prefs.APP_URL + "config.js?t=" + System.currentTimeMillis(), null, emptyMap())
        if (code != 200) throw ApiError("Cannot reach the app server ($code)")
        val url = Regex("url\\s*:\\s*['\"]([^'\"]+)").find(js)?.groupValues?.get(1) ?: throw ApiError("config.js has no url")
        val key = Regex("key\\s*:\\s*['\"]([^'\"]+)").find(js)?.groupValues?.get(1) ?: throw ApiError("config.js has no key")
        Prefs.set(c, "sb_url", url.trimEnd('/')); Prefs.set(c, "sb_key", key)
        return url.trimEnd('/') to key
    }

    private fun saveTokens(j: JSONObject) {
        Prefs.set(c, "access", j.getString("access_token")); Prefs.set(c, "refresh", j.getString("refresh_token"))
        Prefs.setLong(c, "expires", System.currentTimeMillis() + (j.optLong("expires_in", 3600) - 120) * 1000)
    }

    fun login(email: String, password: String) {
        val (url, key) = config()
        val body = JSONObject().put("email", email.trim().lowercase()).put("password", password).toString().toByteArray()
        val (code, text) = http("POST", "$url/auth/v1/token?grant_type=password", body, mapOf("apikey" to key, "Content-Type" to "application/json"))
        if (code >= 300) throw ApiError(if (text.contains("invalid", true)) "Wrong e-mail or password" else "Login failed: $text")
        saveTokens(JSONObject(text)); Prefs.set(c, "email", email.trim().lowercase())
    }

    fun loggedIn() = Prefs.get(c, "refresh") != null

    private fun token(): String {
        val (url, key) = config()
        if (System.currentTimeMillis() < Prefs.long(c, "expires")) Prefs.get(c, "access")?.let { return it }
        val rt = Prefs.get(c, "refresh") ?: throw ApiError("Not signed in")
        val (code, text) = http("POST", "$url/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", rt).toString().toByteArray(),
            mapOf("apikey" to key, "Content-Type" to "application/json"))
        if (code >= 300) { if (code == 400 || code == 401) Prefs.clearLogin(c); throw ApiError("Session expired — sign in again") }
        saveTokens(JSONObject(text)); return Prefs.get(c, "access")!!
    }

    /** POST /rest/v1/rpc/<fn> — returns raw JSON text */
    fun rpc(fn: String, args: JSONObject): String {
        val (url, key) = config()
        val (code, text) = http("POST", "$url/rest/v1/rpc/$fn", args.toString().toByteArray(),
            mapOf("apikey" to key, "Authorization" to "Bearer " + token(), "Content-Type" to "application/json"))
        if (code >= 300) throw ApiError("$fn: " + (runCatching { JSONObject(text).optString("message") }.getOrNull() ?: text))
        return text
    }

    fun me(): JSONObject? = runCatching { JSONObject(rpc("ht_me", JSONObject())) }.getOrNull()

    fun upload(path: String, uri: Uri, mime: String) {
        val (url, key) = config()
        val bytes = c.contentResolver.openInputStream(uri)?.use { ins -> ByteArrayOutputStream().also { ins.copyTo(it) }.toByteArray() } ?: throw ApiError("Cannot read recording")
        val enc = path.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val (code, text) = http("POST", "$url/storage/v1/object/ht-calls/$enc", bytes,
            mapOf("apikey" to key, "Authorization" to "Bearer " + token(), "Content-Type" to mime, "x-upsert" to "true"))
        if (code >= 300) throw ApiError("Upload failed ($code): $text")
    }

}
