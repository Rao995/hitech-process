package org.hitechagro.dialer

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Reads new company-SIM calls from the call log, sends them to the CRM, uploads the phone's own recording,
 *  and shows "Update call status" so the sales person fills the result. */
object CallSync {
    const val CH = "calls"
    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    fun isoOf(ms: Long): String = iso.format(Date(ms))

    fun has(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    fun deviceId(c: Context): String = Settings.Secure.getString(c.contentResolver, Settings.Secure.ANDROID_ID) ?: "dev"

    data class Rec(val uri: Uri, val name: String, val modified: Long, val mime: String)

    /** All audio files in the chosen recordings folder (and one level of sub-folders). */
    fun listRecordings(c: Context, since: Long): List<Rec> {
        val tree = Prefs.get(c, "rec_tree") ?: return emptyList()
        val treeUri = Uri.parse(tree)
        val out = ArrayList<Rec>()
        fun walk(docId: String, depth: Int) {
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val cols = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED, DocumentsContract.Document.COLUMN_MIME_TYPE)
            runCatching {
                c.contentResolver.query(kids, cols, null, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val id = cur.getString(0); val name = cur.getString(1) ?: ""; val mod = cur.getLong(2); val mime = cur.getString(3) ?: ""
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) { if (depth < 2) walk(id, depth + 1) }
                        else if (mod >= since && (mime.startsWith("audio") || Regex("\\.(m4a|mp3|amr|aac|wav|3gp|ogg|opus)$", RegexOption.IGNORE_CASE).containsMatchIn(name)))
                            out.add(Rec(DocumentsContract.buildDocumentUriUsingTree(treeUri, id), name, mod, if (mime.startsWith("audio")) mime else "audio/mpeg"))
                    }
                }
            }
        }
        walk(DocumentsContract.getTreeDocumentId(treeUri), 0)
        return out
    }

    private fun digits(s: String?) = (s ?: "").filter { it.isDigit() }.takeLast(10)

    fun contactName(c: Context, number: String): String? {
        if (!has(c, Manifest.permission.READ_CONTACTS) || number.isBlank()) return null
        return runCatching {
            c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull()
    }

    /** true when this call log row belongs to the company SIM chosen in the app */
    private fun companySim(c: Context, account: String?): Boolean {
        val mode = Prefs.get(c, "sim_mode") ?: "all"
        if (mode == "all") return true
        val ids = (Prefs.get(c, "sim_ids") ?: "").split(',').filter { it.isNotBlank() }
        return account != null && ids.any { id -> account == id || account.startsWith(id) || id.startsWith(account) }
    }

    @SuppressLint("MissingPermission")
    fun run(c: Context): String {
        val api = Api(c)
        if (!api.loggedIn()) return "Not signed in"
        if (!has(c, Manifest.permission.READ_CALL_LOG)) return "Call log permission missing"
        var last = Prefs.long(c, "last_call_ms")
        if (last == 0L) { last = System.currentTimeMillis() - 2 * 3600_000L; Prefs.setLong(c, "last_call_ms", last) }   // first run: last 2 hours only
        val cols = arrayOf(CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION,
            CallLog.Calls.PHONE_ACCOUNT_ID, CallLog.Calls.CACHED_NAME)
        val rows = ArrayList<JSONObject>()
        c.contentResolver.query(CallLog.Calls.CONTENT_URI, cols, "${CallLog.Calls.DATE} > ?", arrayOf(last.toString()), "${CallLog.Calls.DATE} ASC")?.use { cur ->
            while (cur.moveToNext()) {
                if (!companySim(c, cur.getString(5))) continue
                val type = cur.getInt(2)
                val dir = when (type) { CallLog.Calls.INCOMING_TYPE -> "in"; CallLog.Calls.OUTGOING_TYPE -> "out"; CallLog.Calls.MISSED_TYPE -> "missed"; CallLog.Calls.REJECTED_TYPE -> "rejected"; else -> continue }
                rows.add(JSONObject().put("id", cur.getLong(0)).put("phone", cur.getString(1) ?: "").put("direction", dir).put("date", cur.getLong(3))
                    .put("duration_sec", cur.getInt(4)).put("contact_name", cur.getString(6) ?: contactName(c, cur.getString(1) ?: "")))
            }
        }
        var sent = 0; var recs = 0
        val pool = listRecordings(c, last - 60_000).toMutableList()
        for (r in rows) {
            val start = r.getLong("date"); val dur = r.getInt("duration_sec")
            val callId = api.rpc("ht_crm_log_call", JSONObject().put("p", JSONObject()
                .put("phone", r.getString("phone")).put("contact_name", r.optString("contact_name"))
                .put("direction", r.getString("direction")).put("channel", "sim").put("started_at", isoOf(start)).put("duration_sec", dur)
                .put("sim_number", Prefs.get(c, "sim_number") ?: "").put("device_key", deviceId(c) + "-" + r.getLong("id")))).trim().trim('"')
            sent++
            if (dur > 0) {
                // recording finished around call end: modified between start and end + 3 min; prefer files whose name has the number
                val end = start + dur * 1000L
                val ph = digits(r.getString("phone"))
                val match = pool.filter { it.modified in (start - 5_000)..(end + 180_000) }
                    .sortedWith(compareBy({ if (ph.isNotEmpty() && digits(it.name).contains(ph.takeLast(6))) 0 else 1 }, { Math.abs(it.modified - end) })).firstOrNull()
                if (match != null) {
                    runCatching {
                        val ext = match.name.substringAfterLast('.', "m4a")
                        val path = "${Prefs.get(c, "emp_id") ?: "x"}/${isoOf(start).substring(0, 10)}/$callId.$ext"
                        api.upload(path, match.uri, match.mime)
                        api.rpc("ht_crm_attach_recording", JSONObject().put("p_call", callId).put("p_path", path))
                        pool.remove(match); recs++
                        Prefs.set(c, "rec_ok", "1")
                    }
                } else if (dur > 15) Prefs.set(c, "rec_ok", "0")
                notifyStatus(c, callId, r.optString("contact_name").ifBlank { r.getString("phone") }, r.getString("direction"), dur)
            }
            Prefs.setLong(c, "last_call_ms", start)
        }
        heartbeat(c, false)
        val msg = "Synced $sent call(s), $recs recording(s) · " + SimpleDateFormat("dd MMM HH:mm", Locale("en", "IN")).format(Date())
        Prefs.set(c, "last_sync", msg)
        return msg
    }

    fun heartbeat(c: Context, onCall: Boolean) {
        runCatching {
            Api(c).rpc("ht_crm_heartbeat", JSONObject().put("p", JSONObject().put("sim_number", Prefs.get(c, "sim_number") ?: "")
                .put("device_model", Build.MANUFACTURER + " " + Build.MODEL).put("app_version", BuildConfigCompat.version(c)).put("android", Build.VERSION.RELEASE)
                .put("on_call", onCall).put("recording_ok", when (Prefs.get(c, "rec_ok")) { "1" -> true; "0" -> false; else -> JSONObject.NULL })))
        }
    }

    fun channel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CH, "Call status", NotificationManager.IMPORTANCE_HIGH))
    }

    @SuppressLint("MissingPermission")
    fun notifyStatus(c: Context, callId: String, who: String, dir: String, dur: Int) {
        channel(c)
        val open = PendingIntent.getActivity(c, callId.hashCode(), Intent(Intent.ACTION_VIEW, Uri.parse(Prefs.APP_URL + "#/crm/call/" + callId)),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CH).setSmallIcon(R.drawable.ic_call)
            .setContentTitle("Update call status · $who")
            .setContentText((if (dir == "in") "Incoming" else "Outgoing") + " call · " + (dur / 60) + "m " + (dur % 60) + "s — tap to save result & next follow-up")
            .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        if (Build.VERSION.SDK_INT < 33 || has(c, Manifest.permission.POST_NOTIFICATIONS)) NotificationManagerCompat.from(c).notify(callId.hashCode(), n)
    }
}

object BuildConfigCompat {
    fun version(c: Context): String = runCatching { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "" }.getOrDefault("")
}
