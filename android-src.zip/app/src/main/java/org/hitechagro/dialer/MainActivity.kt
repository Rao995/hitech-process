package org.hitechagro.dialer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val green = Color.parseColor("#1B5E20")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(40)) }
        setContentView(ScrollView(this).apply { addView(root) })
        CallSync.channel(this)
        render()
    }
    override fun onResume() { super.onResume(); render() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun title(t: String) = TextView(this).apply { text = t; textSize = 22f; setTypeface(null, Typeface.BOLD); setTextColor(green) }
    private fun head(t: String) = TextView(this).apply { text = t; textSize = 16f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(18), 0, dp(4)); setTextColor(Color.parseColor("#1D2A1F")) }
    private fun note(t: String, color: String = "#5B6158") = TextView(this).apply { text = t; textSize = 13.5f; setTextColor(Color.parseColor(color)); setPadding(0, dp(2), 0, dp(4)) }
    private fun btn(t: String, primary: Boolean = true, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(if (primary) Color.WHITE else green); setBackgroundColor(if (primary) green else Color.parseColor("#E8F3E7"))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }; setOnClickListener { f() } }
    private fun ok(b: Boolean) = if (b) "✅ " else "⚠️ "
    private fun has(p: String) = CallSync.has(this, p)

    private fun render() {
        root.removeAllViews()
        root.addView(title("Hi-Tech Dialer"))
        root.addView(note("Logs company-SIM calls, uploads the phone's call recording to Hi-Tech CRM and asks you to update the call status. Personal SIM is never read."))
        val api = Api(this)
        if (!api.loggedIn()) { renderLogin(); return }
        root.addView(note("Signed in as " + (Prefs.get(this, "email") ?: "") + (Prefs.get(this, "emp_name")?.let { " · $it" } ?: ""), "#1B5E20"))
        root.addView(note(Prefs.get(this, "last_sync") ?: "Not synced yet"))

        // 1 permissions
        val perms = arrayListOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 26) perms.add(Manifest.permission.READ_PHONE_NUMBERS)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { !has(it) }
        root.addView(head(ok(missing.isEmpty()) + "1. Permissions"))
        if (missing.isNotEmpty()) root.addView(btn("Allow phone, call log, contacts & notifications") { requestPermissions(missing.toTypedArray(), 7) })
        else root.addView(note("All allowed."))

        // 2 company SIM
        root.addView(head(ok(Prefs.get(this, "sim_mode") != null) + "2. Company SIM"))
        root.addView(note("Only calls on this SIM are logged and recorded."))
        renderSims()
        val num = EditText(this).apply { hint = "Company mobile number (10 digits)"; inputType = InputType.TYPE_CLASS_PHONE; setText(Prefs.get(this@MainActivity, "sim_number") ?: "") }
        root.addView(num); root.addView(btn("Save number", false) { Prefs.set(this, "sim_number", num.text.toString().filter { it.isDigit() }.takeLast(10)); toast("Saved") })

        // 3 recordings folder
        val tree = Prefs.get(this, "rec_tree")
        root.addView(head(ok(tree != null) + "3. Call recordings folder"))
        root.addView(note(if (tree == null) "Turn ON auto call recording in your Phone app first, make one test call, then pick the folder where the recording is saved (e.g. Recordings/Call, MIUI/sound_recorder/call_rec, Record/Call)."
            else "Folder: " + Uri.decode(tree.substringAfterLast("%3A", tree.substringAfterLast(':'))) + (when (Prefs.get(this, "rec_ok")) { "1" -> " · last recording uploaded ✅"; "0" -> " · ⚠️ last call had no recording — check phone recorder / folder"; else -> "" })))
        root.addView(btn(if (tree == null) "Choose recordings folder" else "Change folder", tree == null) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 11) })
        if (tree != null) root.addView(btn("Test: count recordings of last 7 days", false) {
            Thread { val n = runCatching { CallSync.listRecordings(this, System.currentTimeMillis() - 7 * 86400_000L).size }.getOrDefault(-1)
                runOnUiThread { toast(if (n >= 0) "$n recording file(s) found in last 7 days" else "Cannot read folder — choose again") } }.start() })

        // 4 WhatsApp
        val waOn = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        root.addView(head(ok(waOn) + "4. WhatsApp call log"))
        root.addView(note("Logs WhatsApp calls (who, when, how long). WhatsApp does not allow any app to record its calls."))
        if (!waOn) root.addView(btn("Turn on notification access for Hi-Tech Dialer") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })

        // 5 battery
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val batt = pm.isIgnoringBatteryOptimizations(packageName)
        root.addView(head(ok(batt) + "5. Battery"))
        root.addView(note("Set to Unrestricted so calls sync in the background. On Xiaomi / Vivo / Oppo also turn on Autostart for this app."))
        if (!batt) root.addView(btn("Allow background (no battery restriction)") {
            @SuppressLint("BatteryLife") val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")); runCatching { startActivity(i) } })
        root.addView(btn("Open app settings (Autostart / battery)", false) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) })

        root.addView(head("Actions"))
        root.addView(btn("Sync now") { toast("Syncing…"); Thread { val m = runCatching { CallSync.run(this) }.getOrElse { "Error: " + it.message }; Prefs.set(this, "last_sync", m); runOnUiThread { toast(m); render() } }.start() })
        root.addView(btn("Open Hi-Tech CRM", false) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Prefs.APP_URL + "#/crm/dashboard"))) })
        root.addView(btn("Sign out", false) { Prefs.clearLogin(this); render() })
        root.addView(note("App " + BuildConfigCompat.version(this) + " · " + Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE))
        SyncWorker.schedule(this)
    }

    private fun renderLogin() {
        root.addView(head("Sign in"))
        root.addView(note("Same @hitechagro.org e-mail and password as the Hi-Tech Process app. (Google sign-in users: set a password once in the web app → First time – set password.)"))
        val email = EditText(this).apply { hint = "name@hitechagro.org"; inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS or InputType.TYPE_CLASS_TEXT }
        val pass = EditText(this).apply { hint = "Password"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val msg = note(""); root.addView(email); root.addView(pass)
        root.addView(btn("Sign in") {
            msg.text = "Signing in…"
            Thread {
                val r = runCatching {
                    val api = Api(this); api.login(email.text.toString(), pass.text.toString())
                    val me = api.me() ?: throw Api.ApiError("This e-mail is not registered in the app. Ask Admin.")
                    Prefs.set(this, "emp_id", me.optString("id")); Prefs.set(this, "emp_name", me.optString("name"))
                    Prefs.setLong(this, "last_call_ms", System.currentTimeMillis() - 2 * 3600_000L)
                }
                runOnUiThread { r.exceptionOrNull()?.let { Prefs.clearLogin(this); msg.text = it.message } ?: run { SyncWorker.schedule(this); render() } }
            }.start()
        })
        root.addView(msg)
    }

    @SuppressLint("MissingPermission")
    private fun renderSims() {
        if (!has(Manifest.permission.READ_PHONE_STATE)) { root.addView(note("Allow permissions first to see SIMs.")); return }
        val sm = getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
        val subs = runCatching { sm.activeSubscriptionInfoList }.getOrNull() ?: emptyList()
        val group = RadioGroup(this)
        val mode = Prefs.get(this, "sim_mode"); val chosen = Prefs.get(this, "sim_sub")
        subs.forEach { s ->
            val number = runCatching { if (Build.VERSION.SDK_INT >= 33) sm.getPhoneNumber(s.subscriptionId) else s.number }.getOrNull() ?: ""
            group.addView(RadioButton(this).apply {
                id = View.generateViewId(); text = "SIM ${s.simSlotIndex + 1} · ${s.carrierName}" + (if (number.isNotBlank()) " · $number" else "")
                isChecked = mode == "one" && chosen == s.subscriptionId.toString()
                setOnClickListener { saveSim(s.subscriptionId, runCatching { s.iccId }.getOrNull(), number) }
            })
        }
        group.addView(RadioButton(this).apply { id = View.generateViewId(); text = "This phone has only the company SIM (log all calls)"; isChecked = mode == "all"
            setOnClickListener { Prefs.set(this@MainActivity, "sim_mode", "all"); Prefs.set(this@MainActivity, "sim_ids", ""); toast("All calls on this phone will be logged") } })
        root.addView(group)
    }

    @SuppressLint("MissingPermission")
    private fun saveSim(subId: Int, icc: String?, number: String) {
        val ids = linkedSetOf(subId.toString()); if (!icc.isNullOrBlank()) ids.add(icc)
        runCatching {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val tc = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tc.callCapablePhoneAccounts.forEach { h -> if (Build.VERSION.SDK_INT >= 30 && tm.getSubscriptionId(h) == subId) ids.add(h.id) }
        }
        Prefs.set(this, "sim_mode", "one"); Prefs.set(this, "sim_sub", subId.toString()); Prefs.set(this, "sim_ids", ids.joinToString(","))
        if (number.isNotBlank() && Prefs.get(this, "sim_number").isNullOrBlank()) Prefs.set(this, "sim_number", number.filter { it.isDigit() }.takeLast(10))
        toast("Company SIM saved"); render()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 11 && res == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            Prefs.set(this, "rec_tree", uri.toString()); render()
        }
    }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(r, p, g); render() }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
