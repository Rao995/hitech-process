package org.hitechagro.dialer

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class SyncWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result = try { CallSync.run(applicationContext); Result.success() } catch (e: Exception) {
        Prefs.set(applicationContext, "last_sync", "Error: " + e.message); if (runAttemptCount < 5) Result.retry() else Result.failure()
    }

    companion object {
        private val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        /** after a call ends: wait a few seconds so the phone finishes writing the recording */
        fun soon(c: Context, delaySec: Long = 12) {
            WorkManager.getInstance(c).enqueueUniqueWork("sync-now", ExistingWorkPolicy.REPLACE,
                OneTimeWorkRequestBuilder<SyncWorker>().setInitialDelay(delaySec, TimeUnit.SECONDS).setConstraints(net).build())
        }
        fun schedule(c: Context) {
            WorkManager.getInstance(c).enqueueUniquePeriodicWork("sync-periodic", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).setConstraints(net).build())
        }
    }
}
